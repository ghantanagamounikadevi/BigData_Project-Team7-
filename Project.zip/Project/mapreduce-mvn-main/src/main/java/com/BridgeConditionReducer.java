package com;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.LongWritable;

import java.io.IOException;

public class BridgeConditionReducer extends Reducer<Text, IntWritable, Text, DoubleWritable> {

    @Override
      public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        int sum = 0;
        int count = 0;

        for (IntWritable value : values) {
            sum += value.get();
            count++;
        }

        if (count > 0) {
            double averageRating = (double) sum / count;
            context.write(key, new DoubleWritable(averageRating));
        }
    }
}