package com;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.LongWritable;

import java.io.IOException;public class BridgeConditionMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
   public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] row = value.toString().split("\t");
        if (row.length >= 44) { // Assuming 44 fields in each line
            String county = row[2].trim(); // Assuming COUNTY_CODE_003 is at index 1
            int conditionRating = Integer.parseInt(row[43].trim()); // Assuming BRIDGE_CONDITION is at index 43
            context.write(new Text(county), new IntWritable(conditionRating));
        }
    }
}